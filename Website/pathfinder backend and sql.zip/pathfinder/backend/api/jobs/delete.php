<?php
require_once '../../config/cors.php';
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(["message" => "Unauthorized"]);
    exit();
}

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['job_id'])) {
    http_response_code(400);
    echo json_encode(["message" => "Job ID required"]);
    exit();
}

$jobId = $data['job_id'];
$userId = $_SESSION['user_id'];

$database = new Database();
$db = $database->getConnection();

/**
 * We delete ONLY jobs owned by this employer
 */
$query = "
    DELETE FROM jobs
    WHERE id = :job_id
    AND employer_id = :user_id
";

$stmt = $db->prepare($query);
$stmt->bindParam(":job_id", $jobId);
$stmt->bindParam(":user_id", $userId);

if ($stmt->execute()) {
    echo json_encode(["success" => true]);
} else {
    http_response_code(500);
    echo json_encode(["message" => "Failed to delete job"]);
}
?>