<?php
require_once '../../config/cors.php';
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'employer') {
    http_response_code(401);
    echo json_encode(["message" => "Unauthorized"]);
    exit();
}

$database = new Database();
$db = $database->getConnection();

$query = "
    SELECT 
        a.id,
        a.job_id,
        a.applicant_id,
        a.status,
        a.applied_date,
        u.name AS applicant_name,
        u.email AS applicant_email,
        j.title AS job_title
    FROM applications a
    INNER JOIN jobs j ON a.job_id = j.id
    INNER JOIN users u ON a.applicant_id = u.id
    WHERE j.employer_id = :employer_id
    ORDER BY a.applied_date DESC
";

$stmt = $db->prepare($query);
$stmt->bindParam(':employer_id', $_SESSION['user_id']);
$stmt->execute();

$applicants = [];

while ($row = $stmt->fetch()) {
    $applicants[] = [
        "id" => (string)$row['id'],
        "jobId" => (string)$row['job_id'],
        "jobTitle" => $row['job_title'],
        "applicantId" => (string)$row['applicant_id'],
        "applicantName" => $row['applicant_name'],
        "applicantEmail" => $row['applicant_email'],
        "status" => $row['status'],
        "appliedDate" => $row['applied_date']
    ];
}

http_response_code(200);
echo json_encode($applicants);
?>