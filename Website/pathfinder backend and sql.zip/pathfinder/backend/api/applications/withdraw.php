<?php
require_once '../../config/cors.php';
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(["message" => "Unauthorized"]);
    exit();
}

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['application_id'])) {
    http_response_code(400);
    echo json_encode(["message" => "Application ID required"]);
    exit();
}

$database = new Database();
$db = $database->getConnection();

$query = "DELETE FROM applications 
          WHERE id = :id AND applicant_id = :user_id";

$stmt = $db->prepare($query);
$stmt->bindParam(":id", $data['application_id']);
$stmt->bindParam(":user_id", $_SESSION['user_id']);
$stmt->execute();

echo json_encode(["success" => true]);
