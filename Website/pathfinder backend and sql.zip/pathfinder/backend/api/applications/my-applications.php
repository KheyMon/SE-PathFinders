<?php
require_once '../../config/cors.php';
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(["message" => "Unauthorized"]);
    exit();
}


$database = new Database();
$db = $database->getConnection();

$query = "SELECT 
            a.*,
            j.title,
            j.location,
            j.salary,
            j.company
          FROM applications a
          LEFT JOIN jobs j ON a.job_id = j.id
          WHERE a.applicant_id = :user_id
          ORDER BY a.applied_date DESC";


$stmt = $db->prepare($query);
$stmt->bindParam(":user_id", $_SESSION['user_id']);
$stmt->execute();

$applications = [];
while ($row = $stmt->fetch()) {
    $application = [
        "id" => (string)$row['id'],
        "jobId" => (string)$row['job_id'],

        "jobTitle" => $row['title'],
        "location" => $row['location'],
        "salary" => $row['salary'],

        "appliedDate" => $row['applied_date'],
        "status" => $row['status']
    ];
    array_push($applications, $application);
}

http_response_code(200);
echo json_encode($applications);
?>