<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/cors.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'employer') {
    http_response_code(401);
    echo json_encode(["message" => "Unauthorized"]);
    exit();
}

$database = new Database();
$db = $database->getConnection();
$data = json_decode(file_get_contents("php://input"));

if (!empty($data->job_id)) {
    
    $query = "UPDATE jobs SET 
              title = :title,
              company = :company,
              location = :location,
              job_type = :job_type,
              salary = :salary,
              description = :description,
              requirements = :requirements,
              skills = :skills,
              status = :status
              WHERE id = :job_id AND employer_id = :employer_id";
    
    $stmt = $db->prepare($query);
    
    $skills_json = json_encode($data->skills);
    
    $stmt->bindParam(":job_id", $data->job_id);
    $stmt->bindParam(":employer_id", $_SESSION['user_id']);
    $stmt->bindParam(":title", $data->title);
    $stmt->bindParam(":company", $data->company);
    $stmt->bindParam(":location", $data->location);
    $stmt->bindParam(":job_type", $data->type);
    $stmt->bindParam(":salary", $data->salary);
    $stmt->bindParam(":description", $data->description);
    $stmt->bindParam(":requirements", $data->requirements);
    $stmt->bindParam(":skills", $skills_json);
    $stmt->bindParam(":status", $data->status);
    
    if ($stmt->execute()) {
        http_response_code(200);
        echo json_encode(["message" => "Job updated successfully"]);
    } else {
        http_response_code(500);
        echo json_encode(["message" => "Unable to update job"]);
    }
} else {
    http_response_code(400);
    echo json_encode(["message" => "Incomplete data"]);
}
?>