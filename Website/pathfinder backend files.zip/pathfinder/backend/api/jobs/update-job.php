<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/cors.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'employer') {
    http_response_code(401);
    echo json_encode(["message" => "Unauthorized"]);
    exit();
}

$data = json_decode(file_get_contents("php://input"));

if (
    empty($data->job_id) ||
    empty($data->title) ||
    empty($data->location) ||
    empty($data->salary)
) {
    http_response_code(400);
    echo json_encode(["message" => "Incomplete data"]);
    exit();
}

$database = new Database();
$db = $database->getConnection();

$query = "UPDATE jobs SET
            title = :title,
            location = :location,
            salary = :salary,
            description = :description,
            requirements = :requirements,
            skills = :skills
          WHERE id = :job_id
            AND employer_id = :employer_id";

$stmt = $db->prepare($query);

$skills_json = json_encode($data->skills);

$stmt->bindParam(":title", $data->title);
$stmt->bindParam(":location", $data->location);
$stmt->bindParam(":salary", $data->salary);
$stmt->bindParam(":description", $data->description);
$stmt->bindParam(":requirements", $data->requirements);
$stmt->bindParam(":skills", $skills_json);
$stmt->bindParam(":job_id", $data->job_id);
$stmt->bindParam(":employer_id", $_SESSION['user_id']);

if ($stmt->execute()) {
    echo json_encode(["success" => true, "message" => "Job updated successfully"]);
} else {
    http_response_code(500);
    echo json_encode(["success" => false, "message" => "Failed to update job"]);
}
?>