<?php
require_once '../../config/cors.php';
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(["message" => "Unauthorized"]);
    exit();
}


$database = new Database();
$db = $database->getConnection();

// Get applications for jobs posted by this employer
$query = "SELECT a.*, j.title, j.company, u.name as applicant_name, u.email as applicant_email
          FROM applications a
          LEFT JOIN jobs j ON a.job_id = j.id
          LEFT JOIN users u ON a.applicant_id = u.id
          WHERE j.employer_id = :employer_id
          ORDER BY a.applied_date DESC";

$stmt = $db->prepare($query);
$stmt->bindParam(":employer_id", $_SESSION['user_id']);
$stmt->execute();

$applications = [];
while ($row = $stmt->fetch()) {
    $application = [
        "id" => (string)$row['id'],
        "jobId" => (string)$row['job_id'],
        "jobTitle" => $row['title'],
        "company" => $row['company'],
        "applicantId" => (string)$row['applicant_id'],
        "applicantName" => $row['applicant_name'],
        "applicantEmail" => $row['applicant_email'],
        "appliedDate" => $row['applied_date'],
        "status" => $row['status']
    ];
    array_push($applications, $application);
}

http_response_code(200);
echo json_encode($applications);
?>