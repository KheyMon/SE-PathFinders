<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/cors.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'employer') {
    http_response_code(401);
    echo json_encode(["message" => "Unauthorized"]);
    exit();
}

$database = new Database();
$db = $database->getConnection();
$data = json_decode(file_get_contents("php://input"));

if (!empty($data->application_id) && !empty($data->status)) {
    
    $query = "UPDATE applications a
              INNER JOIN jobs j ON a.job_id = j.id
              SET a.status = :status
              WHERE a.id = :application_id AND j.employer_id = :employer_id";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(":application_id", $data->application_id);
    $stmt->bindParam(":status", $data->status);
    $stmt->bindParam(":employer_id", $_SESSION['user_id']);
    
    if ($stmt->execute()) {
        
        // Create notification for applicant
        $app_query = "SELECT applicant_id, job_id FROM applications WHERE id = :application_id";
        $app_stmt = $db->prepare($app_query);
        $app_stmt->bindParam(":application_id", $data->application_id);
        $app_stmt->execute();
        $app = $app_stmt->fetch();
        
        $job_query = "SELECT title FROM jobs WHERE id = :job_id";
        $job_stmt = $db->prepare($job_query);
        $job_stmt->bindParam(":job_id", $app['job_id']);
        $job_stmt->execute();
        $job = $job_stmt->fetch();
        
        $notif_query = "INSERT INTO notifications (user_id, type, title, message) 
                        VALUES (:user_id, 'application-status', :title, :message)";
        $notif_stmt = $db->prepare($notif_query);
        $notif_title = "Application " . $data->status;
        $notif_message = "Your application for " . $job['title'] . " has been " . strtolower($data->status);
        $notif_stmt->bindParam(":user_id", $app['applicant_id']);
        $notif_stmt->bindParam(":title", $notif_title);
        $notif_stmt->bindParam(":message", $notif_message);
        $notif_stmt->execute();
        
        http_response_code(200);
        echo json_encode(["message" => "Application status updated successfully"]);
    } else {
        http_response_code(500);
        echo json_encode(["message" => "Unable to update application status"]);
    }
} else {
    http_response_code(400);
    echo json_encode(["message" => "Incomplete data"]);
}
?>