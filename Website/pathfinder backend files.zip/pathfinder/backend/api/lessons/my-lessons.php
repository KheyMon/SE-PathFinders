<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/cors.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'employer') {
    http_response_code(401);
    echo json_encode(["message" => "Unauthorized"]);
    exit();
}

$database = new Database();
$db = $database->getConnection();

$query = "SELECT * FROM lessons WHERE creator_id = :creator_id ORDER BY created_date DESC";

$stmt = $db->prepare($query);
$stmt->bindParam(":creator_id", $_SESSION['user_id']);
$stmt->execute();

$lessons = [];
while ($row = $stmt->fetch()) {
    $lesson = [
        "id" => (string)$row['id'],
        "title" => $row['title'],
        "description" => $row['description'],
        "content" => $row['content'],
        "visibility" => $row['visibility'],
        "createdBy" => (string)$row['creator_id'],
        "createdDate" => $row['created_date']
    ];
    array_push($lessons, $lesson);
}

http_response_code(200);
echo json_encode($lessons);
?>