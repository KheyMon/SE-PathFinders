<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/cors.php';

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(["message" => "Unauthorized"]);
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Get all public lessons or lessons assigned to user
$query = "SELECT l.*, u.name as creator_name 
          FROM lessons l
          LEFT JOIN users u ON l.creator_id = u.id
          WHERE l.visibility = 'public'
          ORDER BY l.created_date DESC";

$stmt = $db->prepare($query);
$stmt->execute();

$lessons = [];
while ($row = $stmt->fetch()) {
    $lesson = [
        "id" => (string)$row['id'],
        "title" => $row['title'],
        "description" => $row['description'],
        "content" => $row['content'],
        "visibility" => $row['visibility'],
        "createdBy" => (string)$row['creator_id'],
        "creatorName" => $row['creator_name'],
        "createdDate" => $row['created_date']
    ];
    array_push($lessons, $lesson);
}

http_response_code(200);
echo json_encode($lessons);
?>