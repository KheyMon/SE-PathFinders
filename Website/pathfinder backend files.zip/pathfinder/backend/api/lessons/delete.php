<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/cors.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'employer') {
    http_response_code(401);
    echo json_encode(["message" => "Unauthorized"]);
    exit();
}

$database = new Database();
$db = $database->getConnection();
$data = json_decode(file_get_contents("php://input"));

if (!empty($data->lesson_id)) {
    
    $query = "DELETE FROM lessons WHERE id = :lesson_id AND creator_id = :creator_id";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(":lesson_id", $data->lesson_id);
    $stmt->bindParam(":creator_id", $_SESSION['user_id']);
    
    if ($stmt->execute()) {
        http_response_code(200);
        echo json_encode(["message" => "Lesson deleted successfully"]);
    } else {
        http_response_code(500);
        echo json_encode(["message" => "Unable to delete lesson"]);
    }
} else {
    http_response_code(400);
    echo json_encode(["message" => "Incomplete data"]);
}
?>