<?php
header("Content-Type: application/json");
require_once '../../config/cors.php';
require_once '../../config/database.php';

session_start();

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode([]);
    exit();
}

$database = new Database();
$db = $database->getConnection();

$query = "SELECT id, user_id, type, title, message, is_read, created_at
          FROM notifications
          WHERE user_id = :user_id
          ORDER BY created_at DESC";

$stmt = $db->prepare($query);
$stmt->bindParam(":user_id", $_SESSION['user_id']);
$stmt->execute();

$notifications = [];

while ($row = $stmt->fetch()) {
    $notifications[] = [
        "id" => (string)$row['id'],
        "userId" => (string)$row['user_id'],
        "type" => $row['type'],
        "title" => $row['title'],
        "message" => $row['message'],
        "read" => (bool)$row['is_read'],
        "timestamp" => $row['created_at']
    ];
}

http_response_code(200);
echo json_encode($notifications);
