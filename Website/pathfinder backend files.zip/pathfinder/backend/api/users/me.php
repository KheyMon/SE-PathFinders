<?php
require_once '../../config/cors.php';
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(["message" => "Unauthorized"]);
    exit;
}


error_reporting(E_ALL);
ini_set('display_errors', 1);


$database = new Database();
$db = $database->getConnection();

$query = "SELECT 
            id,
            name,
            email,
            phone,
            location,
            desired_position,
            experience,
            education,
            about,
            skills,
            user_type
          FROM users
          WHERE id = :id
          LIMIT 1";

$stmt = $db->prepare($query);
$stmt->bindParam(':id', $_SESSION['user_id']);
$stmt->execute();

$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    http_response_code(404);
    echo json_encode(["message" => "User not found"]);
    exit;
}

$user['skills'] = $user['skills']
    ? json_decode($user['skills'])
    : [];

http_response_code(200);
echo json_encode($user);
?>