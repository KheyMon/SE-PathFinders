<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/cors.php';

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(["message" => "Unauthorized"]);
    exit();
}

$database = new Database();
$db = $database->getConnection();
$data = json_decode(file_get_contents("php://input"));

$query = "UPDATE users SET 
          name = :name,
          phone = :phone,
          location = :location,
          website = :website,
          description = :description,
          company = :company
          WHERE id = :user_id";

$stmt = $db->prepare($query);

$stmt->bindParam(":user_id", $_SESSION['user_id']);
$stmt->bindParam(":name", $data->name);
$stmt->bindParam(":phone", $data->phone);
$stmt->bindParam(":location", $data->location);
$stmt->bindParam(":website", $data->website);
$stmt->bindParam(":description", $data->description);
$stmt->bindParam(":company", $data->company);

if ($stmt->execute()) {
    http_response_code(200);
    echo json_encode(["message" => "Profile updated successfully"]);
} else {
    http_response_code(500);
    echo json_encode(["message" => "Unable to update profile"]);
}
?>