<?php
session_start();
require_once '../../config/cors.php';
require_once '../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(["success" => false, "message" => "Unauthorized"]);
    exit;
}

$data = json_decode(file_get_contents("php://input"));

$db = (new Database())->getConnection();

$query = "UPDATE users SET
  name = :name,
  phone = :phone,
  location = :location,
  desired_position = :desired_position,
  experience = :experience,
  education = :education,
  about = :about,
  skills = :skills
WHERE id = :id";

$stmt = $db->prepare($query);

$stmt->execute([
  ':id' => $_SESSION['user_id'],
  ':name' => $data->name,
  ':phone' => $data->phone,
  ':location' => $data->location,
  ':desired_position' => $data->desired_position,
  ':experience' => $data->experience,
  ':education' => $data->education,
  ':about' => $data->about,
  ':skills' => json_encode($data->skills ?? [])
]);

echo json_encode(["success" => true]);
?>