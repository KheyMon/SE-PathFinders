<?php
require_once '../../config/cors.php';
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(["success" => false, "message" => "Unauthorized"]);
    exit;
}

$data = json_decode(file_get_contents("php://input"));

$database = new Database();
$db = $database->getConnection();

$query = "UPDATE users SET
            company = :company,
            phone = :phone,
            location = :location,
            website = :website,
            industry = :industry,
            description = :description
          WHERE id = :id AND user_type = 'employer'";

$stmt = $db->prepare($query);

$stmt->bindParam(':company', $data->company);
$stmt->bindParam(':phone', $data->phone);
$stmt->bindParam(':location', $data->location);
$stmt->bindParam(':website', $data->website);
$stmt->bindParam(':industry', $data->industry);
$stmt->bindParam(':description', $data->description);
$stmt->bindParam(':id', $_SESSION['user_id']);

if ($stmt->execute()) {
    echo json_encode(["success" => true]);
} else {
    echo json_encode(["success" => false]);
}
?>