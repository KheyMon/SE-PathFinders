<?php
require_once '../../config/cors.php';
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(["message" => "Unauthorized"]);
    exit;
}

$database = new Database();
$db = $database->getConnection();

$query = "SELECT 
            id,
            name,
            email,
            company,
            phone,
            location,
            website,
            industry,
            description
          FROM users
          WHERE id = :id AND user_type = 'employer'
          LIMIT 1";

$stmt = $db->prepare($query);
$stmt->bindParam(':id', $_SESSION['user_id']);
$stmt->execute();

$employer = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$employer) {
    http_response_code(404);
    echo json_encode(["message" => "Employer not found"]);
    exit;
}

echo json_encode($employer);

?>