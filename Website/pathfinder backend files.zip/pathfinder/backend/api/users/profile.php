<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/cors.php';

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(["message" => "Unauthorized"]);
    exit();
}

$database = new Database();
$db = $database->getConnection();

$query = "SELECT id, name, email, user_type, company, phone, location, website, description 
          FROM users 
          WHERE id = :user_id";

$stmt = $db->prepare($query);
$stmt->bindParam(":user_id", $_SESSION['user_id']);
$stmt->execute();

if ($stmt->rowCount() > 0) {
    $user = $stmt->fetch();
    
    http_response_code(200);
    echo json_encode([
        "id" => (string)$user['id'],
        "name" => $user['name'],
        "email" => $user['email'],
        "type" => $user['user_type'],
        "company" => $user['company'],
        "phone" => $user['phone'],
        "location" => $user['location'],
        "website" => $user['website'],
        "description" => $user['description']
    ]);
} else {
    http_response_code(404);
    echo json_encode(["message" => "User not found"]);
}
?>