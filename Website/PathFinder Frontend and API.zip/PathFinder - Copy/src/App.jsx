import api from './services/api';
import React, { useState, createContext, useContext, useEffect } from 'react';
import { Header } from './components/Header';
import { LandingPage } from './components/LandingPage';
import { LoginPage } from './components/LoginPage';
import { RegisterPage } from './components/RegisterPage';
import { JobSeekerDashboard } from './components/JobSeekerDashboard';
import { JobSeekerProfile } from './components/JobSeekerProfile';
import { JobListings } from './components/JobListings';
import { ApplicationStatus } from './components/ApplicationStatus';
import { SkillBuildHome } from './components/SkillBuildHome';
import { SkillModule } from './components/SkillModule';
import { Assessment } from './components/Assessment';
import { EmployerDashboard } from './components/EmployerDashboard';
import { EmployerProfile } from './components/EmployerProfile';
import { PostJob } from './components/PostJob';
import { ManageJobs } from './components/ManageJobs';
import { ViewApplicants } from './components/ViewApplicants';
import { ManageLessons } from './components/ManageLessons';
import { CreateLesson } from './components/CreateLesson';

const AppContext = createContext(null);
export const useApp = () => {
  return useContext(AppContext);
};
export default function App() {

  // Navigation & User
  const [page, setPage] = useState('landing');
  const [user, setUser] = useState(null);

  // Selected items
  const [selectedJob, setSelectedJob] = useState(null);
  const [selectedModule, setSelectedModule] = useState(null);
  const [selectedLesson, setSelectedLesson] = useState(null);

  // Resume state
  const [hasResume, setHasResume] = useState(false);

  // Data states
  const [jobs, setJobs] = useState([
    {
      id: '1',
      title: 'Senior Software Engineer',
      company: 'Tech Solutions Cebu',
      location: 'Cebu City, Cebu',
      type: 'Full-time',
      salary: '₱80,000 - ₱120,000',
      description: 'We are seeking an experienced software engineer to join our team in Cebu IT Park.',
      requirements: 'Bachelor\'s degree in Computer Science, 5+ years experience',
      skills: ['JavaScript', 'React', 'Node.js', 'SQL'],
      postedDate: '2024-01-15',
      postedBy: 'employer1'
    },
    {
      id: '2',
      title: 'Marketing Manager',
      company: 'Brand Dynamics Philippines',
      location: 'Cebu Business Park, Cebu City',
      type: 'Full-time',
      salary: '₱60,000 - ₱85,000',
      description: 'Looking for a creative marketing manager to lead our campaigns in Cebu.',
      requirements: '3+ years in marketing, excellent communication skills',
      skills: ['SEO', 'Content Strategy', 'Analytics', 'Social Media'],
      postedDate: '2024-01-18',
      postedBy: 'employer2'
    },
    {
      id: '3',
      title: 'Data Analyst',
      company: 'DataCorp Cebu',
      location: 'Cebu IT Park, Cebu City',
      type: 'Full-time',
      salary: '₱50,000 - ₱70,000',
      description: 'Join our analytics team to drive data-driven decisions at our Cebu office.',
      requirements: 'Strong analytical skills, proficiency in SQL and Python',
      skills: ['SQL', 'Python', 'Tableau', 'Excel'],
      postedDate: '2024-01-20',
      postedBy: 'employer1'
    },
    {
      id: '4',
      title: 'UX/UI Designer',
      company: 'Creative Studios Cebu',
      location: 'Mandaue City, Cebu',
      type: 'Contract',
      salary: '₱55,000 - ₱75,000',
      description: 'Design beautiful and intuitive user interfaces for web applications.',
      requirements: 'Portfolio required, 2+ years experience with design tools',
      skills: ['Figma', 'Adobe XD', 'User Research', 'Prototyping'],
      postedDate: '2024-01-22',
      postedBy: 'employer3'
    },
    {
      id: '5',
      title: 'Customer Success Manager',
      company: 'SaaS Innovations Cebu',
      location: 'Cebu City, Cebu',
      type: 'Full-time',
      salary: '₱45,000 - ₱65,000',
      description: 'Help our customers achieve success with our platform from our Cebu office.',
      requirements: 'Experience in customer-facing roles, excellent problem-solving',
      skills: ['Communication', 'CRM Software', 'Customer Support', 'Training'],
      postedDate: '2024-01-25',
      postedBy: 'employer2'
    }
  ]);
  const [applications, setApplications] = useState([]);
  const [employerLessons, setEmployerLessons] = useState([]);
  const [notifications, setNotifications] = useState([]);

  useEffect(() => {
    const saved = localStorage.getItem('notifications');
    if (saved) {
      setNotifications(JSON.parse(saved));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('notifications', JSON.stringify(notifications));
  }, [notifications]);

  // Helper functions
  const addNotification = (userId, type, title, message) => {
    const newNotification = {
      id: String(Date.now()),
      userId,
      type,
      title,
      message,
      timestamp: new Date().toISOString(),
      read: false
    };
    setNotifications([newNotification, ...notifications]);
  };

  const markAsRead = (notificationId) => {
    setNotifications(notifications.map(n => 
      n.id === notificationId ? {...n, read: true} : n
    ));
  };

  const markAllAsRead = () => {
    setNotifications(notifications.map(n => ({...n, read: true})));
  };

  const validPages = [
    'landing',
    'login',
    'register',
    'jobseeker-dashboard',
    'jobseeker-profile',
    'job-listings',
    'application-status',
    'skillbuild',
    'skill-module',
    'assessment',
    'employer-dashboard',
    'employer-profile',
    'post-job',
    'manage-jobs',
    'view-applicants',
    'manage-lessons',
    'create-lesson'
  ];

  const safePage = validPages.includes(page) ? page : 'landing';

  // Context value
  const appData = {
    currentPage: safePage,
    setCurrentPage: setPage,
    user,
    setUser,
    jobs,
    setJobs,
    applications,
    setApplications,
    employerLessons,
    setEmployerLessons,
    selectedJob,
    setSelectedJob,
    selectedModule,
    setSelectedModule,
    selectedLesson,
    setSelectedLesson,
    notifications,
    setNotifications,
    addNotification,
    markAsRead,
    markAllAsRead,
    hasResume,
    setHasResume
  };

  return (
    <AppContext.Provider value={appData}>
      <div className="min-h-screen bg-gray-50">
        {page !== 'login' && page !== 'register' && <Header />}
        
        {page === 'landing' && <LandingPage />}
        {page === 'login' && <LoginPage />}
        {page === 'register' && <RegisterPage />}
        {page === 'jobseeker-dashboard' && <JobSeekerDashboard />}
        {page === 'jobseeker-profile' && <JobSeekerProfile />}
        {page === 'job-listings' && <JobListings />}
        {page === 'application-status' && <ApplicationStatus />}
        {page === 'skillbuild' && <SkillBuildHome />}
        {page === 'skill-module' && <SkillModule />}
        {page === 'assessment' && <Assessment />}
        {page === 'employer-dashboard' && <EmployerDashboard />}
        {page === 'employer-profile' && <EmployerProfile />}
        {page === 'post-job' && <PostJob />}
        {page === 'manage-jobs' && <ManageJobs />}
        {page === 'view-applicants' && <ViewApplicants />}
        {page === 'manage-lessons' && <ManageLessons />}
        {page === 'create-lesson' && <CreateLesson />}
      </div>
    </AppContext.Provider>
  );
}