import React, { useEffect, useState } from 'react';
import api from '../services/api';
import { useApp } from '../App';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import {
  Building2,
  Mail,
  Phone,
  MapPin,
  Globe,
  ArrowLeft,
  Check
} from 'lucide-react';

export function EmployerProfile() {
  const { user, setUser, setCurrentPage } = useApp();

  const [editing, setEditing] = useState(false);
  const [saved, setSaved] = useState(false);

  // 🔑 Employer profile local state
  const [data, setData] = useState(null);

  // =========================================
  // ✅ FETCH EMPLOYER PROFILE (ON LOAD)
  // =========================================
  useEffect(() => {
    const fetchEmployerProfile = async () => {
      try {
        const profile = await api.getMyEmployerProfile();

        setData({
          company: profile.company ?? '',
          email: profile.email ?? '',
          phone: profile.phone ?? '',
          location: profile.location ?? '',
          industry: profile.industry ?? '',
          website: profile.website ?? '',
          about: profile.description ?? '', // 🔥 correct mapping
          employees: profile.employees ?? ''
        });
      } catch (err) {
        console.error('Failed to load employer profile', err);
      }
    };

    fetchEmployerProfile();
  }, []);

  // =========================================
  // 💾 SAVE EMPLOYER PROFILE
  // =========================================
  const save = async () => {
    try {
      const payload = {
        company: data.company,
        phone: data.phone,
        location: data.location,
        industry: data.industry,
        website: data.website,
        description: data.about // 🔥 backend column
      };

      const res = await api.updateEmployerProfile(payload);

      if (res.success) {
        // ✅ Safely update global user (no overwrite of id/type)
        setUser(prev => ({
          ...prev,
          company: data.company,
          phone: data.phone,
          location: data.location,
          industry: data.industry,
          website: data.website,
          description: data.about
        }));

        setEditing(false);
        setSaved(true);
        setTimeout(() => setSaved(false), 3000);
      }
    } catch (err) {
      console.error('Employer profile update failed', err);
    }
  };

  // =========================================
  // 🔒 GUARD
  // =========================================
  if (!user || user.type !== 'employer') {
    return (
      <div className="min-h-screen flex items-center justify-center text-gray-500">
        Session expired. Please log in again.
      </div>
    );
  }

  // =========================================
  // ⏳ LOADING
  // =========================================
  if (!data) {
    return (
      <div className="min-h-screen flex items-center justify-center text-gray-500">
        Loading company profile...
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">

        {/* Back Button */}
        <Button
          variant="ghost"
          onClick={() => setCurrentPage('employer-dashboard')}
          className="mb-6"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Dashboard
        </Button>

        {/* Success Message */}
        {saved && (
          <div className="mb-6 bg-green-50 border border-green-200 rounded-lg p-4 flex items-center gap-3">
            <div className="w-8 h-8 bg-green-600 rounded-full flex items-center justify-center">
              <Check className="w-5 h-5 text-white" />
            </div>
            <p className="text-green-900">Profile updated successfully!</p>
          </div>
        )}

        {/* Header */}
        <div className="mb-8">
          <h1 className="mb-2">Company Profile</h1>
          <p className="text-gray-600">Manage your company information</p>
        </div>

        {/* Company Summary */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex items-start gap-6">
              <div className="w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center">
                <Building2 className="w-12 h-12 text-blue-600" />
              </div>

              <div className="flex-1">
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <h2 className="mb-1">{data.company}</h2>
                    <p className="text-gray-600">{data.industry}</p>
                  </div>

                  <Button onClick={() => setEditing(!editing)}>
                    {editing ? 'Cancel' : 'Edit Profile'}
                  </Button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-4 text-gray-600">
                  <div className="flex items-center gap-2">
                    <Mail className="w-4 h-4" />
                    <span>{data.email}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone className="w-4 h-4" />
                    <span>{data.phone}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    <span>{data.location}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Globe className="w-4 h-4" />
                    <span>{data.website}</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Edit / View Mode */}
        {editing ? (
          <Card>
            <CardContent className="pt-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Company Name</Label>
                  <Input
                    value={data.company}
                    onChange={e => setData({ ...data, company: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Industry</Label>
                  <Input
                    value={data.industry}
                    onChange={e => setData({ ...data, industry: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Email</Label>
                  <Input value={data.email} disabled />
                </div>

                <div className="space-y-2">
                  <Label>Phone</Label>
                  <Input
                    value={data.phone}
                    onChange={e => setData({ ...data, phone: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Location</Label>
                  <Input
                    value={data.location}
                    onChange={e => setData({ ...data, location: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Website</Label>
                  <Input
                    value={data.website}
                    onChange={e => setData({ ...data, website: e.target.value })}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>About Company</Label>
                <Textarea
                  rows={4}
                  value={data.about}
                  onChange={e => setData({ ...data, about: e.target.value })}
                />
              </div>

              <Button onClick={save} className="w-full">
                Save Changes
              </Button>
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardContent className="pt-6">
              <h3 className="mb-3">About Company</h3>
              <p className="text-gray-600">{data.about}</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
