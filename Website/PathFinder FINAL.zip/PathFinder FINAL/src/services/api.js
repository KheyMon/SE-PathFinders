const API_BASE_URL = 'http://localhost:8080/pathfinder/backend/api';


class ApiService {
  
  // Auth
  async register(userData) {
    const response = await fetch(`${API_BASE_URL}/auth/register.php`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      
      body: JSON.stringify(userData)
    });
    return response.json();
  }

  async login(email, password) {
    const response = await fetch(`${API_BASE_URL}/auth/login.php`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ email, password })
    });
    return response.json();
  }

  // Jobs
  async getAllJobs() {
    const response = await fetch(`${API_BASE_URL}/jobs/list.php`, {
    });
    return response.json();
  }

  async createJob(jobData) {
    const response = await fetch(`${API_BASE_URL}/jobs/create.php`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
       credentials: 'include',
      body: JSON.stringify(jobData)
    });
    return response.json();
  }

  async getMyJobs() {
  const response = await fetch(`${API_BASE_URL}/jobs/my-jobs.php`, {
    credentials: 'include',
  });
  return response.json();
  }

  async deleteJob(jobId) {
    const response = await fetch(`${API_BASE_URL}/jobs/delete.php`, {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
       credentials: 'include',
      body: JSON.stringify({ job_id: jobId })
    });
    return response.json();
  }

  async updateJob(jobId, data) {
  const res = await fetch(`${API_BASE_URL}/jobs/update.php`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include',
    body: JSON.stringify({
      job_id: jobId,
      ...data
    })
  });
    return res.json();
  }



  // Applications
  async applyForJob(jobId) {
    const response = await fetch(`${API_BASE_URL}/applications/apply.php`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ job_id: jobId })
    });
    return response.json();
  }

  async getMyApplications() {
    const response = await fetch(`${API_BASE_URL}/applications/my-applications.php`, {
      credentials: 'include',
    });
    return response.json();
  }

  async getJobApplications(jobId) {
    const response = await fetch(`${API_BASE_URL}/applications/list.php?job_id=${jobId}`, {
       credentials: 'include'  
    });
    return response.json();

  }

  async updateApplicationStatus(applicationId, status) {
    const response = await fetch(`${API_BASE_URL}/applications/update-status.php`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
       credentials: 'include',
      body: JSON.stringify({ application_id: applicationId, status })
    });
    return response.json();
  }

  async getEmployerApplicants() {
  const response = await fetch(
    `${API_BASE_URL}/applications/employer-applicants.php`,
    { credentials: 'include' }
  );
  return response.json();
  }

  async withdrawApplication(applicationId) {
  const res = await fetch(
    `${API_BASE_URL}/applications/withdraw.php`,
    {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ application_id: applicationId })
    }
  );
  return res.json();
  }




  // Lessons
  async getAllLessons() {
    const response = await fetch(`${API_BASE_URL}/lessons/list.php`, {
    credentials: 'include',
    });
    return response.json();
  }

  async createLesson(lessonData) {
    const response = await fetch(`${API_BASE_URL}/lessons/create.php`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify(lessonData)
    });
    return response.json();
  }

  async getMyLessons() {
    const response = await fetch(`${API_BASE_URL}/lessons/my-lessons.php`, {
     credentials: 'include',
    });
    return response.json();
  }

  async deleteLesson(lessonId) {
    const response = await fetch(`${API_BASE_URL}/lessons/delete.php`, {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ lesson_id: lessonId })
    });
    return response.json();
  }

  // Notifications
  async getNotifications() {
    const response = await fetch(`${API_BASE_URL}/notifications/list.php`, {
     credentials: 'include'
    });
    return response.json();
  }

  async markNotificationAsRead(notificationId) {
    const response = await fetch(`${API_BASE_URL}/notifications/mark-read.php`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
       credentials: 'include',
      body: JSON.stringify({ notification_id: notificationId })
    });
    return response.json();
  }

  async markAllNotificationsAsRead() {
    const response = await fetch(`${API_BASE_URL}/notifications/mark-all-read.php`, {
      method: 'PUT',
       credentials: 'include'
    });
    return response.json();
  }

  // Profile
  async updateProfile(profileData) {
    const response = await fetch(`${API_BASE_URL}/users/update-jobseeker.php`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify(profileData)
    });
    return response.json();
  }

  // Get logged-in user profile
  async getMyProfile() {
    const response = await fetch(`${API_BASE_URL}/users/me.php`, {
     method: 'GET',
     credentials: 'include'
    });
  if (!response.ok) {
    throw new Error('Failed to fetch profile');
  }
    return response.json();
  }

  // Employer Profile
async getMyEmployerProfile() {
  const res = await fetch(`${API_BASE_URL}/users/me-employer.php`, {
    credentials: 'include'
  });
  return res.json();
}

async updateEmployerProfile(data) {
  const res = await fetch(`${API_BASE_URL}/users/update-employer.php`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include',
    body: JSON.stringify(data)
  });
  return res.json();
}


}

export default new ApiService();