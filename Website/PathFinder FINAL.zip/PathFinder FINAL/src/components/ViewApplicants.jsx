import { useEffect, useState } from 'react';
import api from '../services/api';
import { useApp } from '../App';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from './ui/dialog';
import { Users, ArrowLeft } from 'lucide-react';

export function ViewApplicants() {
  const { user, setCurrentPage, applications, setApplications, addNotification, jobs } = useApp();
  const [filterJob, setFilterJob] = useState('all');
  const [selectedApplicant, setSelectedApplicant] = useState(null);

  if (!user || user.type !== 'employer') return null;

  const myJobs = jobs.filter(
    job => job.postedBy === user.id || job.company === user.company
  );

  useEffect(() => {
    const fetchApplications = async () => {
      try {
        const res = await api.getEmployerApplicants();
        setApplications(Array.isArray(res) ? res : []);
      } catch (err) {
        console.error(err);
        setApplications([]);
      }
    };
    fetchApplications();
  }, []);

  const handleUpdateStatus = async (applicationId, status) => {
    try {
      await api.updateApplicationStatus(applicationId, status);

      addNotification({
        type: 'success',
        message: `Application ${status}`
      });

      const refreshed = await api.getEmployerApplicants();
      setApplications(Array.isArray(refreshed) ? refreshed : []);
    } catch (err) {
      console.error(err);
      addNotification({
        type: 'error',
        message: 'Failed to update application status'
      });
    }
  };

  const filtered =
    filterJob === 'all'
      ? applications
      : applications.filter(app => app.jobId === filterJob);

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-6xl mx-auto px-4">
        <Button
          variant="ghost"
          onClick={() => setCurrentPage('employer-dashboard')}
          className="mb-6"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Dashboard
        </Button>

        <h1 className="mb-6">View Applicants</h1>

        {/* Filter */}
        <Card className="mb-6">
          <CardContent className="pt-6 flex items-center gap-4">
            <span>Filter by Job:</span>
            <Select value={filterJob} onValueChange={setFilterJob}>
              <SelectTrigger className="w-64">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Jobs</SelectItem>
                {myJobs.map(job => (
                  <SelectItem key={job.id} value={job.id}>
                    {job.title}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <span className="ml-auto">{filtered.length} applicant(s)</span>
          </CardContent>
        </Card>

        {/* Applicants */}
        {filtered.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p>No applicants yet</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {filtered.map(applicant => (
              <Card key={applicant.id}>
                <CardContent className="p-6 flex justify-between">
                  <div>
                    <h3 className="mb-1">{applicant.applicantName}</h3>
                    <p className="text-sm text-gray-600">
                      Job ID: {applicant.jobId}
                    </p>
                    <p className="text-sm text-gray-500">
                      Applied on {applicant.appliedDate}
                    </p>
                  </div>

                  <div className="flex flex-col gap-2">
                    <span className="px-3 py-1 bg-orange-50 text-orange-600 rounded-full text-sm text-center">
                      {applicant.status}
                    </span>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setSelectedApplicant(applicant)}
                    >
                      View
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => handleUpdateStatus(applicant.id, 'accepted')}
                    >
                      Accept
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleUpdateStatus(applicant.id, 'rejected')}
                    >
                      Reject
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Dialog */}
        <Dialog open={!!selectedApplicant} onOpenChange={() => setSelectedApplicant(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{selectedApplicant?.applicantName}</DialogTitle>
            </DialogHeader>

            <p>Job ID: {selectedApplicant?.jobId}</p>
            <p>Status: {selectedApplicant?.status}</p>
            <p>Applied on: {selectedApplicant?.appliedDate}</p>

            <DialogFooter>
              <Button variant="outline" onClick={() => setSelectedApplicant(null)}>
                Close
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
