import api from './services/api';
import React, { useState, createContext, useContext, useEffect } from 'react';
import { Header } from './components/Header';
import { LandingPage } from './components/LandingPage';
import { LoginPage } from './components/LoginPage';
import { RegisterPage } from './components/RegisterPage';
import { JobSeekerDashboard } from './components/JobSeekerDashboard';
import { JobSeekerProfile } from './components/JobSeekerProfile';
import { JobListings } from './components/JobListings';
import { ApplicationStatus } from './components/ApplicationStatus';
import { SkillBuildHome } from './components/SkillBuildHome';
import { SkillModule } from './components/SkillModule';
import { Assessment } from './components/Assessment';
import { EmployerDashboard } from './components/EmployerDashboard';
import { EmployerProfile } from './components/EmployerProfile';
import { PostJob } from './components/PostJob';
import { ManageJobs } from './components/ManageJobs';
import { ViewApplicants } from './components/ViewApplicants';
import { ManageLessons } from './components/ManageLessons';
import { CreateLesson } from './components/CreateLesson';

const AppContext = createContext(null);
export const useApp = () => {
  return useContext(AppContext);
};
export default function App() {

  // Navigation & User
  const [page, setPage] = useState('landing');
  const [user, setUser] = useState(null);

  // Selected items
  const [selectedJob, setSelectedJob] = useState(null);
  const [selectedModule, setSelectedModule] = useState(null);
  const [selectedLesson, setSelectedLesson] = useState(null);

  // Resume state
  const [hasResume, setHasResume] = useState(false);

  const [jobs, setJobs] = useState([]);
  const [applications, setApplications] = useState([]);
  const [employerLessons, setEmployerLessons] = useState([]);
  const [notifications, setNotifications] = useState([]);

  useEffect(() => {
    const saved = localStorage.getItem('notifications');
    if (saved) {
      setNotifications(JSON.parse(saved));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('notifications', JSON.stringify(notifications));
  }, [notifications]);

  // Helper functions
  const addNotification = (userId, type, title, message) => {
    const newNotification = {
      id: String(Date.now()),
      userId,
      type,
      title,
      message,
      timestamp: new Date().toISOString(),
      read: false
    };
    setNotifications([newNotification, ...notifications]);
  };

  const markAsRead = (notificationId) => {
    setNotifications(notifications.map(n => 
      n.id === notificationId ? {...n, read: true} : n
    ));
  };

  const markAllAsRead = () => {
    setNotifications(notifications.map(n => ({...n, read: true})));
  };

  const validPages = [
    'landing',
    'login',
    'register',
    'jobseeker-dashboard',
    'jobseeker-profile',
    'job-listings',
    'application-status',
    'skillbuild',
    'skill-module',
    'assessment',
    'employer-dashboard',
    'employer-profile',
    'post-job',
    'manage-jobs',
    'view-applicants',
    'manage-lessons',
    'create-lesson'
  ];

  const safePage = validPages.includes(page) ? page : 'landing';

  // Context value
  const appData = {
    currentPage: safePage,
    setCurrentPage: setPage,
    user,
    setUser,
    jobs,
    setJobs,
    applications,
    setApplications,
    employerLessons,
    setEmployerLessons,
    selectedJob,
    setSelectedJob,
    selectedModule,
    setSelectedModule,
    selectedLesson,
    setSelectedLesson,
    notifications,
    setNotifications,
    addNotification,
    markAsRead,
    markAllAsRead,
    hasResume,
    setHasResume
  };

  return (
    <AppContext.Provider value={appData}>
      <div className="min-h-screen bg-gray-50">
        {page !== 'login' && page !== 'register' && <Header />}
        
        {page === 'landing' && <LandingPage />}
        {page === 'login' && <LoginPage />}
        {page === 'register' && <RegisterPage />}
        {page === 'jobseeker-dashboard' && <JobSeekerDashboard />}
        {page === 'jobseeker-profile' && <JobSeekerProfile />}
        {page === 'job-listings' && <JobListings />}
        {page === 'application-status' && <ApplicationStatus />}
        {page === 'skillbuild' && <SkillBuildHome />}
        {page === 'skill-module' && <SkillModule />}
        {page === 'assessment' && <Assessment />}
        {page === 'employer-dashboard' && <EmployerDashboard />}
        {page === 'employer-profile' && <EmployerProfile />}
        {page === 'post-job' && <PostJob />}
        {page === 'manage-jobs' && <ManageJobs />}
        {page === 'view-applicants' && <ViewApplicants />}
        {page === 'manage-lessons' && <ManageLessons />}
        {page === 'create-lesson' && <CreateLesson />}
      </div>
    </AppContext.Provider>
  );
}